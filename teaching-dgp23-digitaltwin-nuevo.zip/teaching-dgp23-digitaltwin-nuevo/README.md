# teaching-dgp23-digitaltwin-team4

Instrucciones para ejecutar el proyecto:
    - Antes de ejecutar el proyecto es necesario tener instalado:
        - Flask
        - Python
        - SQLAlchemy
        - Pandas
        

    - Con todo esto instalado, necesitamos estar en el directorio /theBayWest para que la base de datos, y el contenido de la aplicacion funcione correctamente.

    - Una vez en el directorio correcto, simplemente necesitaremos ejecutar el comando python app.py en la terminal y automaticamente se desplegará el proyecto en local en la direccion http://127.0.0.1:4000/, asignada por defecto.


Instrucciones para ejecutar los tests:
    - Antes de ejecutar los tests es necesario tener instalado:
        - PyTest

    - Al igual que antes necesitamos estar en el directorio /theBayWest para que la base de datos y los endpoints funcionen correctamente.

    - Una vez en el directorio correcto, ejecutaremos el comando pytest testing.py para ejecutar el archivo y obtener el resultado de las pruebas unitarias.


Instrucciones para ejecutar pylint:
    - Antes de ejecutar pylint es necesario tener instalado:
        - PyLint

    - Para comprobar la correctitud del codigo desarrollado en python, simplemente tendremos que ejecutar el comando pylint xxx.py siendo 'xxx' la ubicacion del archivo que queremos ejecutar.

